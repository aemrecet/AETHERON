import React from 'react';
import { TabView } from '../types';

interface SidebarProps {
  activeTab: TabView;
  setActiveTab: (tab: TabView) => void;
}

const NavIcon: React.FC<{ id: TabView; active: boolean }> = ({ id, active }) => {
  const color = active ? '#eaf3ff' : '#86a0c5';
  const sw = active ? '1.9' : '1.65';

  switch (id) {
    case TabView.ASK:
      return (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
        </svg>
      );
    case TabView.MARKETS:
      return (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
        </svg>
      );
    case TabView.PULSE:
      return (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10" />
          <path d="M12 6v6l4 2" />
        </svg>
      );
    case TabView.ONCHAIN:
      return (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
          <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
          <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
        </svg>
      );
    case TabView.INSIDER:
      return (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
          <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
          <path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
      );
    case TabView.NEWS:
      return (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2" />
          <path d="M18 14h-8" />
          <path d="M15 18h-5" />
          <path d="M10 6h8v4h-8V6Z" />
        </svg>
      );
    default:
      return null;
  }
};

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: TabView.ASK, label: 'Ask', shortLabel: 'Ask' },
    { id: TabView.MARKETS, label: 'Markets', shortLabel: 'Markets' },
    { id: TabView.PULSE, label: 'Pulse', shortLabel: 'Pulse' },
    { id: TabView.ONCHAIN, label: 'On-Chain', shortLabel: 'Chain' },
    { id: TabView.INSIDER, label: 'Insider', shortLabel: 'Insider' },
    { id: TabView.NEWS, label: 'Feeds', shortLabel: 'Feeds' },
  ];

  return (
    <>
      <header
        className="hidden md:flex items-center w-full fixed top-0 left-0 right-0 z-50 h-[58px] border-b"
        style={{
          background: 'rgba(8, 14, 24, 0.78)',
          backdropFilter: 'blur(18px) saturate(145%)',
          WebkitBackdropFilter: 'blur(18px) saturate(145%)',
          borderColor: 'var(--color-border-subtle)',
        }}
      >
        <div className="max-w-[1620px] w-full mx-auto px-6 flex items-center gap-6">
          <button
            className="flex items-center cursor-pointer shrink-0 select-none gap-2.5"
            onClick={() => setActiveTab(TabView.ASK)}
          >
            <div
              className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{
                background: 'linear-gradient(140deg, rgba(93, 158, 255, 0.34), rgba(31, 198, 214, 0.2))',
                border: '1px solid rgba(148, 194, 253, 0.46)',
              }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#cfe4ff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2L2 7l10 5 10-5-10-5z" />
                <path d="M2 17l10 5 10-5" />
                <path d="M2 12l10 5 10-5" />
              </svg>
            </div>
            <span className="text-[13px] font-semibold tracking-[0.22em] uppercase text-[#edf4ff]">ÆTHRON</span>
          </button>

          <nav className="flex items-center gap-1.5 overflow-x-auto scrollbar-hide">
            {menuItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className="nav-item h-9 px-3.5 rounded-lg text-[12px] font-semibold transition-all inline-flex items-center gap-1.5"
                  style={isActive
                    ? {
                        color: '#eaf3ff',
                        border: '1px solid rgba(132, 176, 235, 0.4)',
                        background: 'linear-gradient(180deg, rgba(86, 149, 235, 0.24), rgba(20, 34, 55, 0.42))',
                        boxShadow: 'inset 0 0 0 1px rgba(143, 186, 244, 0.2)',
                      }
                    : {
                        color: '#8ea8cd',
                        border: '1px solid transparent',
                        background: 'transparent',
                      }}
                >
                  <span className="opacity-90 scale-[0.85]">
                    <NavIcon id={item.id} active={isActive} />
                  </span>
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="flex-1" />

          <div
            className="flex items-center gap-2 rounded-lg px-2.5 py-1.5"
            style={{
              background: 'rgba(18, 31, 50, 0.65)',
              border: '1px solid var(--color-border-subtle)',
            }}
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#1dd39a] opacity-60"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#1dd39a]"></span>
            </span>
            <span className="text-[10px] uppercase tracking-[0.08em] text-[#a9c2e4] font-medium">Live Data</span>
          </div>
        </div>
      </header>

      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 pb-[max(env(safe-area-inset-bottom),8px)] px-2">
        <div
          className="rounded-2xl p-1.5"
          style={{
            background: 'rgba(8, 14, 24, 0.92)',
            backdropFilter: 'blur(18px) saturate(145%)',
            WebkitBackdropFilter: 'blur(18px) saturate(145%)',
            border: '1px solid var(--color-border-subtle)',
            boxShadow: '0 14px 36px rgba(4, 10, 24, 0.36)',
          }}
        >
          <div className="flex items-stretch justify-around">
            {menuItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className="flex flex-col items-center justify-center gap-1 flex-1 py-2 rounded-xl relative"
                  style={isActive ? { background: 'rgba(86, 149, 235, 0.18)' } : {}}
                >
                  <NavIcon id={item.id} active={isActive} />
                  <span className="text-[9px] font-semibold" style={{ color: isActive ? '#eaf3ff' : '#8ea8cd' }}>{item.shortLabel}</span>
                  {isActive && (
                    <span
                      className="absolute top-1.5 w-1.5 h-1.5 rounded-full"
                      style={{ background: '#8cc2ff' }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>
    </>
  );
};
