import React, { useState, useRef, useEffect } from 'react';
import { Stock } from '../types';
import { askGemini } from '../services/geminiService';

interface AskViewProps {
  stocks: Stock[];
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const DotGrid: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resize();
    window.addEventListener('resize', resize);

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const spacing = 28;
      const cols = Math.ceil(canvas.width / spacing) + 1;
      const rows = Math.ceil(canvas.height / spacing) + 1;
      const cx = canvas.width * 0.48;
      const cy = canvas.height * 0.34;
      const maxDist = Math.sqrt(cx * cx + cy * cy);

      for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
          const x = i * spacing;
          const y = j * spacing;
          const dx = x - cx;
          const dy = y - cy;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const normDist = dist / maxDist;

          const wave = Math.sin(dist * 0.006 - time * 0.45) * 0.5 + 0.5;
          const fadeOut = Math.max(0, 1 - normDist * 1.18);
          const alpha = (0.015 + wave * 0.04) * fadeOut;
          const radius = (0.4 + wave * 0.65) * (0.65 + fadeOut * 0.38);

          if (alpha < 0.003) continue;

          ctx.beginPath();
          ctx.arc(x, y, radius, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(108, 170, 255, ${alpha})`;
          ctx.fill();
        }
      }

      time += 0.016;
      animId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none" style={{ zIndex: 0 }} />;
};

const escapeHtml = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const formatMarkdown = (text: string): string => {
  let html = escapeHtml(text);

  html = html.replace(/^### (.+)$/gm, '<h3 class="text-[14px] font-semibold text-[#edf5ff] mt-5 mb-2">$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2 class="text-[15px] font-semibold text-[#edf5ff] mt-6 mb-2">$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1 class="text-[16px] font-semibold text-[#edf5ff] mt-6 mb-3">$1</h1>');

  html = html.replace(/\*\*(.+?)\*\*/g, '<strong class="font-semibold text-[#f7fbff]">$1</strong>');
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');

  html = html.replace(/`([^`]+)`/g, '<code class="px-1.5 py-0.5 rounded-md text-[12px] font-mono text-[#9fd0ff] bg-[rgba(104,161,236,0.16)] border border-[rgba(145,192,250,0.2)]">$1</code>');

  html = html.replace(/^- (.+)$/gm, '<li class="text-[14px] text-[#c8d7ee] leading-[1.75] pl-1">$1</li>');
  html = html.replace(/(<li.*<\/li>\n?)+/g, (m) => `<ul class="my-3 space-y-1 list-disc list-outside ml-5">${m}</ul>`);

  html = html.replace(/^(\d+)\. (.+)$/gm, '<li class="text-[14px] text-[#c8d7ee] leading-[1.75] pl-1">$2</li>');

  html = html.replace(/\n\n/g, '</p><p class="text-[14px] text-[#c8d7ee] leading-[1.75] mb-3">');
  html = html.replace(/\n/g, '<br/>');
  html = `<p class="text-[14px] text-[#c8d7ee] leading-[1.75] mb-3">${html}</p>`;

  return html;
};

export const AskView: React.FC<AskViewProps> = ({ stocks }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isChat, setIsChat] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const landingInputRef = useRef<HTMLInputElement>(null);
  const chatInputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (isChat) {
      setTimeout(() => chatInputRef.current?.focus(), 120);
    } else {
      setTimeout(() => landingInputRef.current?.focus(), 180);
    }
  }, [isChat]);

  const buildContext = () => {
    const top = stocks
      .slice(0, 30)
      .map((s) => `${s.symbol}: $${s.price.toFixed(2)} (${s.changePercent >= 0 ? '+' : ''}${s.changePercent.toFixed(2)}%)`)
      .join(', ');

    return `Live market data: ${top}`;
  };

  const handleSubmit = async (text?: string) => {
    const query = text || input.trim();
    if (!query || loading) return;

    setIsChat(true);
    setInput('');

    const userMsg: Message = { role: 'user', content: query };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setLoading(true);

    try {
      const history = newMessages.map((m) => ({ role: m.role, content: m.content }));
      const reply = await askGemini(query, buildContext(), history);
      setMessages((prev) => [...prev, { role: 'assistant', content: reply }]);
    } catch {
      setMessages((prev) => [...prev, { role: 'assistant', content: 'Connection error. Please try again.' }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const prompts = [
    { label: 'Macro Pulse', desc: 'Rate expectations this week' },
    { label: 'Trend Scan', desc: 'Best momentum setups today' },
    { label: 'Relative View', desc: 'SOL vs ETH strength' },
    { label: 'Risk Desk', desc: 'Key downside scenarios' },
    { label: 'Flow Check', desc: 'Whale activity summary' },
    { label: 'Swing Plan', desc: 'NASDAQ technical map' },
  ];

  if (!isChat) {
    return (
      <div className="relative flex flex-col" style={{ minHeight: 'calc(100vh - 58px)' }}>
        <DotGrid />

        <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 sm:px-6">
          <div className="w-full max-w-[760px] mx-auto" style={{ marginTop: '-34px' }}>
            <div className="flex justify-center mb-6">
              <span
                className="text-[10px] uppercase tracking-[0.12em] px-3 py-1 rounded-full"
                style={{
                  color: '#b8cff0',
                  background: 'rgba(61, 110, 184, 0.22)',
                  border: '1px solid rgba(133, 173, 230, 0.35)',
                }}
              >
                Institutional AI Terminal
              </span>
            </div>

            <h1 className="text-center text-[34px] sm:text-[44px] font-semibold text-[#f4f9ff] tracking-[-0.03em] leading-[1.08] mb-4">
              What should we decode in the market?
            </h1>
            <p className="text-center text-[14px] text-[#9bb3d3] max-w-[560px] mx-auto mb-10 leading-relaxed">
              Ask for tactical setups, macro interpretation, portfolio risk mapping, or cross-asset comparisons.
            </p>

            <div
              className="relative mb-10 p-2 rounded-2xl"
              style={{
                background: 'linear-gradient(160deg, rgba(95, 149, 224, 0.24), rgba(13, 22, 38, 0.42) 45%)',
                border: '1px solid rgba(129, 172, 233, 0.34)',
                boxShadow: '0 16px 34px rgba(4, 10, 24, 0.36)',
              }}
            >
              <input
                ref={landingInputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask anything about markets, sectors, tokens, or strategy..."
                className="w-full h-[56px] pl-5 pr-16 text-[15px] text-[#f4f9ff] rounded-xl placeholder:text-[#7f98bd]"
                style={{
                  background: 'rgba(8, 14, 24, 0.84)',
                  border: '1px solid rgba(129, 172, 233, 0.24)',
                  outline: 'none',
                }}
              />

              <button
                onClick={() => handleSubmit()}
                disabled={!input.trim()}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200"
                style={{
                  background: input.trim()
                    ? 'linear-gradient(140deg, #4f99f8 0%, #53b8f3 100%)'
                    : 'rgba(120, 142, 176, 0.22)',
                  border: input.trim() ? '1px solid rgba(164, 205, 255, 0.8)' : '1px solid rgba(130, 152, 184, 0.32)',
                  opacity: input.trim() ? 1 : 0.45,
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={input.trim() ? '#f7fbff' : '#90a8c9'} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-w-[640px] mx-auto">
              {prompts.map((p, i) => (
                <button
                  key={i}
                  onClick={() => handleSubmit(`${p.label}: ${p.desc}`)}
                  className="ask-chip group text-left px-4 py-3 rounded-xl"
                  style={{
                    background: 'linear-gradient(180deg, rgba(20, 31, 50, 0.84), rgba(13, 22, 36, 0.88))',
                    border: '1px solid rgba(122, 159, 210, 0.24)',
                  }}
                >
                  <div className="text-[12px] font-semibold text-[#c3d7f2] group-hover:text-[#e5f0ff] transition-colors">{p.label}</div>
                  <div className="text-[11px] text-[#7f98bd] group-hover:text-[#b0c8e8] transition-colors mt-0.5 line-clamp-1">{p.desc}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex flex-col" style={{ minHeight: 'calc(100vh - 58px)' }}>
      <DotGrid />

      <div className="relative z-10 flex-1 flex flex-col max-w-[880px] w-full mx-auto px-4 sm:px-6 pt-7 pb-36">
        <div className="space-y-5">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} slide-up`}>
              {msg.role === 'assistant' && (
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mr-3 mt-1"
                  style={{
                    background: 'linear-gradient(135deg, rgba(88, 148, 232, 0.28), rgba(26, 158, 170, 0.2))',
                    border: '1px solid rgba(140, 185, 245, 0.4)',
                  }}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d8eaff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2L2 7l10 5 10-5-10-5z" />
                    <path d="M2 17l10 5 10-5" />
                    <path d="M2 12l10 5 10-5" />
                  </svg>
                </div>
              )}

              {msg.role === 'user' ? (
                <div
                  className="px-5 py-3.5 rounded-2xl max-w-[78%]"
                  style={{
                    background: 'linear-gradient(135deg, rgba(84, 143, 226, 0.32), rgba(14, 24, 40, 0.9))',
                    border: '1px solid rgba(124, 168, 232, 0.36)',
                    boxShadow: '0 8px 20px rgba(7, 15, 30, 0.3)',
                  }}
                >
                  <p className="text-[14px] text-[#f5f9ff] leading-relaxed">{msg.content}</p>
                </div>
              ) : (
                <div
                  className="max-w-[90%] min-w-0 px-4 py-3 rounded-2xl"
                  style={{
                    background: 'linear-gradient(180deg, rgba(16, 25, 40, 0.86), rgba(10, 16, 26, 0.92))',
                    border: '1px solid rgba(121, 157, 207, 0.2)',
                  }}
                >
                  <div dangerouslySetInnerHTML={{ __html: formatMarkdown(msg.content) }} />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex justify-start slide-up">
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mr-3 mt-1"
                style={{
                  background: 'linear-gradient(135deg, rgba(88, 148, 232, 0.28), rgba(26, 158, 170, 0.2))',
                  border: '1px solid rgba(140, 185, 245, 0.4)',
                }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d8eaff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2L2 7l10 5 10-5-10-5z" />
                  <path d="M2 17l10 5 10-5" />
                  <path d="M2 12l10 5 10-5" />
                </svg>
              </div>
              <div className="flex items-center gap-1.5 py-3 pl-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#7db4ff] opacity-50 animate-pulse" />
                <span className="w-1.5 h-1.5 rounded-full bg-[#7db4ff] opacity-50 animate-pulse" style={{ animationDelay: '200ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-[#7db4ff] opacity-50 animate-pulse" style={{ animationDelay: '400ms' }} />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 z-20 md:pb-6 pb-20 px-0">
        <div className="absolute inset-0" style={{ background: 'linear-gradient(transparent, rgba(7, 11, 18, 0.96) 58%)' }} />
        <div className="relative max-w-[880px] mx-auto px-4 sm:px-6">
          <div
            className="relative p-2 rounded-2xl"
            style={{
              background: 'linear-gradient(160deg, rgba(95, 149, 224, 0.24), rgba(13, 22, 38, 0.42) 45%)',
              border: '1px solid rgba(129, 172, 233, 0.34)',
              boxShadow: '0 16px 34px rgba(4, 10, 24, 0.36)',
            }}
          >
            <textarea
              ref={chatInputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask a follow-up about the same setup..."
              rows={1}
              className="w-full pl-4 pr-14 py-3.5 text-[15px] text-[#f4f9ff] rounded-xl resize-none placeholder:text-[#7f98bd]"
              style={{
                background: 'rgba(8, 14, 24, 0.84)',
                border: '1px solid rgba(129, 172, 233, 0.24)',
                outline: 'none',
              }}
            />
            <button
              onClick={() => handleSubmit()}
              disabled={!input.trim() || loading}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200"
              style={{
                background: input.trim()
                  ? 'linear-gradient(140deg, #4f99f8 0%, #53b8f3 100%)'
                  : 'rgba(120, 142, 176, 0.22)',
                border: input.trim() ? '1px solid rgba(164, 205, 255, 0.8)' : '1px solid rgba(130, 152, 184, 0.32)',
                opacity: input.trim() ? 1 : 0.45,
              }}
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={input.trim() ? '#f7fbff' : '#90a8c9'} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
